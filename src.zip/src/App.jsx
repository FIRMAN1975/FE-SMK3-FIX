import { BrowserRouter, Routes, Route } from "react-router-dom";

import BerandaPage from "./features/profil/pages/BerandaPage";
import BeritaPage from "./features/profil/pages/BeritaPage";
import PortofolioPage from "./features/profil/pages/PortofolioPage";
import ProfilPage from "./features/profil/pages/ProfilPage";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<BerandaPage />} />
        <Route path="/berita" element={<BeritaPage />} />
        <Route path="/profil" element={<ProfilPage />} />
        <Route path="/portofolio" element={<PortofolioPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
